#ifndef IFJ_IFJ17BUILTINS_H
#define IFJ_IFJ17BUILTINS_H
void print_builtins(FILE *f);
#endif
