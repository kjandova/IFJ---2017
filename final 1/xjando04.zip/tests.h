#ifndef IFJ_TESTS_H
#define IFJ_TESTS_H

void tests_init(char * path);
void tests_run(char * path);
void scanner_tests(char * path);

#endif // IFJ_TESTS_H
